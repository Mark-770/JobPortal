

<div class="card">

    <div class="card-header">
        Menu
    </div>
    <div class="card-body">
        <ul class="list-group">
            <li class="list-group-item">
                <a href="/dashboard">Dashboard</a>
            </li>
            <li class="list-group-item">
                <a href="/dashboard/create">Create post</a>
            </li>
            <li class="list-group-item">
                <a href="/dashboard/trash">Trash</a>
            </li>
            <li class="list-group-item">
                <a href="/dashboard/create">Create Testimonial</a>
            </li>
            <li class="list-group-item">
                <a href="/testimonial/">View Testimonial</a>
            </li>
            <li class="list-group-item">
                <a href="/dashboard/jobs">View Jobs</a>
            </li>

        </ul>
    </div>
</div>
