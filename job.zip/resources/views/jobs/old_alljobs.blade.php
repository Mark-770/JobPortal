@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">

                <form action="{{ route('alljobs') }}" method="GET">
                    <div class="form-inline">
                        <div class="form-group">
                            <label for="">Keyword&nbsp;</label>
                            <input type="text" name="title" class="form-control">&nbsp;&nbsp;
                        </div>
                        <div class="form-group">
                            <label for="type">Employment type&nbsp;</label>
                            <select name="type" id="" class="form-control">
                                <option value="">-select-</option>
                                <option value="fulltime">fulltime</option>
                                <option value="parttime">parttime</option>
                                <option value="casual">casual</option>
                            </select>&nbsp;&nbsp;
                        </div>
                        <div class="form-group">
                            <label for="category">Category&nbsp;</label>
                            <select name="category_id" class="form-control">
                                <option value="">-select-</option>
                                @foreach(App\Category::all() as $cat)

                                    <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                                @endforeach
                            </select>&nbsp;&nbsp;
                        </div>
                        <div class="form-group">
                            <label for="address">Address&nbsp;</label>
                            <input type="text" name="address" class="form-control">&nbsp;&nbsp;
                        </div>
                       <div class="form-group">
                           <button type="submit" class="btn btn-outline-success">
                               Search
                           </button>
                       </div>
                    </div>

                </form>

            <table class="table">
                <thead>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                </thead>
                <tbody>
                @foreach($jobs as $job)
                    <tr>
                        <td><img src="{{ asset('uploads/logo') }}/{{$job->company->logo}}" width="80" alt="avatar"></td>
                        <td>position: {{$job->position}}<br><br>
                            <i class="fas fa-clock" aria-hidden="true"></i>&nbsp; {{$job->type}}
                        </td>

                        <td><i class="fas fa-map-marker" aria-hidden="true"></i>&nbsp;Address: {{$job->address}}</td>
                        <td><i class="fas fa-globe" aria-hidden="true"></i>&nbsp;Data:{{$job->created_at->diffForHumans()}}</td>
                        <td>
                            <a href="{{ route('jobs.show',[$job->id , $job->slug]) }}">
                                <button class="btn btn-success btn-sm">Apply</button>
                            </a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            {{ $jobs->appends(Illuminate\Support\Facades\Request::except('page'))->links() }}
        </div>

    </div>

@endsection

<style>
    .fas{
        color:#4183D7;
    }
</style>
